package com.example.myapplicationcs360_walker_skylar;

import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;

import com.example.myapplicationcs360_walker_skylar.databinding.FragmentSecondBinding;

import java.util.ArrayList;
import android.telephony.SmsManager;


public class SecondFragment extends Fragment {

    private FragmentSecondBinding binding;
    InvDatabase databaseHelper;
    private ArrayList<InventoryItem> itemArrayList;
    private InventoryAdapter adapter;


    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentSecondBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //Lets me use the database
        databaseHelper = new InvDatabase(getContext());

        //Puts data into a list format
        itemArrayList = new ArrayList<>();

        //Set up grid for inventory
        binding.recyclerView.setLayoutManager(new GridLayoutManager(getContext(),2));

        //adaptor for recycler view
        adapter = new InventoryAdapter(

                //Item name, quantity, and 2 buttons to add or delete
                itemArrayList,

                item -> {
                    databaseHelper.increaseQuantity(item.item);
                    loadItems();
                },

                item -> {
                    databaseHelper.deleteItem(item.item);
                    loadItems();
                }
        );
        binding.recyclerView.setAdapter(adapter);

        //loads data
        loadItems();

        //Controls add item button
        binding.buttonAdd.setOnClickListener(v -> {
            String item = binding.itemText.getText().toString();
            String quantity = binding.quantityText.getText().toString();


            if (!item.isEmpty() && !quantity.isEmpty()) {
                int quantity1 = Integer.parseInt(quantity);

                databaseHelper.addItem(item, quantity1);

                //Crashes app when turned on. getDefault is deprecated
                //SmsManager smsManager = SmsManager.getDefault();
                //smsManager.sendTextMessage("+650-555-1212", null, "New item added to Inventory", null, null);

                loadItems();
            }
        });

        //Controls back button
        binding.buttonBack.setOnClickListener(v ->
                NavHostFragment.findNavController(SecondFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment)

        );
    }

    private void loadItems() {
        itemArrayList.clear();

        Cursor cursor = databaseHelper.getAllItems();

        if (cursor.moveToFirst()) {
            do {
                //gets item name and quantity based on column
                String item = cursor.getString(1);
                int quantity = cursor.getInt(2);

                itemArrayList.add(new InventoryItem(item, quantity));
            }
            while (cursor.moveToNext());

        }
        cursor.close();
        adapter.updateList(itemArrayList);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}
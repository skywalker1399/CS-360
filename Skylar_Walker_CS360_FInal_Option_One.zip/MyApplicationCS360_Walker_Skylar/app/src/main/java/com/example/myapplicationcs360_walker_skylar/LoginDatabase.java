package com.example.myapplicationcs360_walker_skylar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import androidx.annotation.Nullable;


public class LoginDatabase extends SQLiteOpenHelper {

    public static final String databaseName = "login.db";

    //Database info
    public static final class LoginTable {

        //database variables
        private static final String TABLE = "userInfo";
        private static final String USERNAME = "Username";
        private static final String PASSWORD = "password";
    }

    public LoginDatabase(Context context) {
        super(context, "login.db", null, 1);
    }


    //Creates our table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table " +
                LoginTable.TABLE + " (" +
                LoginTable.USERNAME + " text," +
                LoginTable.PASSWORD + " text)");
    }

    //Handles version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + LoginTable.TABLE);
        onCreate(db);

    }

    //Used to add users to the database
    public long addUser(String userName, String password) {
        SQLiteDatabase db = getWritableDatabase();

        //sets values for new user
        ContentValues values = new ContentValues();
        values.put(LoginTable.USERNAME, userName);
        values.put(LoginTable.PASSWORD, password);

        long newUser = db.insert(LoginTable.TABLE, null, values);
        return newUser;

    }

    //checks if user is in database
    public boolean checkLoginInfo(String username, String password){
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from " + LoginTable.TABLE + " where username = ? and password = ?", new String[]{username, password});

        if (cursor.getCount() > 0) {
            return true;
        }

        else {
            return false;
        }

    }

}

package com.example.myapplicationcs360_walker_skylar;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.navigation.fragment.NavHostFragment;

import com.example.myapplicationcs360_walker_skylar.databinding.FragmentFirstBinding;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;
    LoginDatabase databaseHelper;


    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //binding.button1.setOnClickListener(v ->
                //NavHostFragment.findNavController(FirstFragment.this)
                        //.navigate(R.id.action_FirstFragment_to_SecondFragment)
        //);

        databaseHelper = new LoginDatabase(requireContext());

        //Checks when login button is pressed
         binding.button1.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String username = binding.usernameText.getText().toString();
                 String password = binding.passwordText.getText().toString();

                 //Checks for empty user inputs
                 if (username.isEmpty() || password.isEmpty())
                     Toast.makeText( getContext(),"Please enter username and password", Toast.LENGTH_SHORT).show();


                 else {
                     boolean checkLoginInfo = databaseHelper.checkLoginInfo(username, password);

                     //Checks username and password combination
                     if (checkLoginInfo == true) {
                         Toast.makeText(getContext(), "Login Successful", Toast.LENGTH_SHORT).show();
                         NavHostFragment.findNavController(FirstFragment.this)
                                 .navigate(R.id.action_FirstFragment_to_SecondFragment);

                     }

                     //Gives message if invalid login info
                     else {
                         Toast.makeText(getContext(), "Failed to login", Toast.LENGTH_SHORT).show();
                     }
                 }
             }

         });

         //Button for creating a user
         binding.button2.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View v) {
                 String username = binding.usernameText.getText().toString();
                 String password = binding.passwordText.getText().toString();

                 //Makes sure there is a username and password
                 if (username.isEmpty() || password.isEmpty())
                     Toast.makeText( getContext(),"Please enter username and password", Toast.LENGTH_SHORT).show();


                 else {
                     boolean checkNewUserInfo = databaseHelper.checkLoginInfo(username, password);

                     //Checks if username and password combination is already in database
                     if (checkNewUserInfo == true) {
                         Toast.makeText(getContext(), "Login already exist", Toast.LENGTH_SHORT).show();

                     }
                     //adds user to database
                     else {
                         databaseHelper.addUser(username, password);
                         Toast.makeText(getContext(), "New user added", Toast.LENGTH_SHORT).show();
                         NavHostFragment.findNavController(FirstFragment.this)
                                 .navigate(R.id.action_FirstFragment_to_SecondFragment);
                     }


                 }

             }
         });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}
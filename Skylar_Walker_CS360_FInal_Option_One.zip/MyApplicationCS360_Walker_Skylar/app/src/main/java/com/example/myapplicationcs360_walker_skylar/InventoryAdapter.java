package com.example.myapplicationcs360_walker_skylar;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

//Controls our grid view
public class InventoryAdapter  extends RecyclerView.Adapter<InventoryAdapter.ViewHolder> {

    //Grabs the item to start
    private List<InventoryItem> items;

    //Used for buttons in grid
    public interface onAddClick {
        void onClick(InventoryItem item);
    }

    public interface onDeleteClick {
        void onClick(InventoryItem item);
    }

    private onAddClick addClick;
    private onDeleteClick deleteClick;

    //Grid parts
    public InventoryAdapter(List<InventoryItem> items, onAddClick addClick,
                            onDeleteClick deleteClick) {
        this.items = items;
        this.addClick = addClick;
        this.deleteClick = deleteClick;
    }

    //Items for each grid
    public static class ViewHolder extends RecyclerView.ViewHolder{

        TextView item, quantity;
        Button addButton, deleteButton;

        public ViewHolder(View itemView) {

            super(itemView);

            //Grabs info from XML variables for use with java
            item = itemView.findViewById(R.id.itemName);
            quantity = itemView.findViewById(R.id.itemQuantity);
            addButton = itemView.findViewById(R.id.buttonAdd);
            deleteButton = itemView.findViewById(R.id.buttonDelete);
        }
    }


    //New row on grid
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_inventory, parent, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {

        //gets the item for position on grid
        InventoryItem item = items.get(position);

        //puts item name and quantity in grid
        holder.item.setText(item.item);
        holder.quantity.setText(String.valueOf(item.quantity));

        //handles buttons in grid
        holder.addButton.setOnClickListener(v -> addClick.onClick(item));
        holder.deleteButton.setOnClickListener(v -> deleteClick.onClick(item));
    }

    //Total items to show
    @Override
    public int getItemCount() {
        return items.size();
    }

    //Always shows new list
    public void updateList(List<InventoryItem> newList) {
        items = newList;
        notifyDataSetChanged();
    }
}

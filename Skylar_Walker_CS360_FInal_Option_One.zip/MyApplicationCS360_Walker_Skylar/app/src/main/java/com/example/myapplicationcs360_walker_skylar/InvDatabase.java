package com.example.myapplicationcs360_walker_skylar;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import androidx.annotation.Nullable;

public class InvDatabase extends SQLiteOpenHelper {

    public static final String databaseName = "inv.db";

    //Database info
    public static final class InvTable {

        //database variables
        private static final String TABLE = "userInfo";
        private static final String ID = "id";
        private static final String ITEM = "item";
        private static final String QUANTITY = "quantity";
    }

    public InvDatabase(Context context) {
        super(context, "inv.db", null, 1);
    }

    //Creates our table
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " +
                InvTable.TABLE + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                InvTable.ITEM + " TEXT, " +
                InvTable.QUANTITY + " INTEGER)" );
    }


    //Handles version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + InvDatabase.InvTable.TABLE);
        onCreate(db);

    }


   //Used to add an item to the inventory
    public long addItem(String item, Integer quantity) {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(InvTable.ITEM, item);
        values.put(InvTable.QUANTITY, quantity);

        long newItem = db.insert(InvTable.TABLE, null, values);
        return newItem;

    }

    //Checks if item is already in inventory
    public boolean checkItemInfo(String item) {
        SQLiteDatabase db = getWritableDatabase();
        Cursor cursor = db.rawQuery("Select * from " + InvTable.TABLE + " where item = ?", new String[]{item});

        if (cursor.getCount() > 0) {
            return true;
        }

        else {
            return false;
        }
    }

    //increase item quantity
    public void increaseQuantity(String item) {
    SQLiteDatabase db = getWritableDatabase();
    db.execSQL(" UPDATE " + InvTable.TABLE + " SET " +
            InvTable.QUANTITY + " = " + InvTable.QUANTITY + " +1" +
            " WHERE " + InvTable.ITEM + " = ? ", new Object[]{item});
    }

    //Delete item from database
    public void deleteItem(String item) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(InvTable.TABLE, InvTable.ITEM + " = ? ", new String[]{item});
    }

    //Get all item data for loading
    public Cursor getAllItems() {
        SQLiteDatabase db = getReadableDatabase();
        return db.rawQuery(" SELECT * FROM " + InvTable.TABLE, null);
    }




}

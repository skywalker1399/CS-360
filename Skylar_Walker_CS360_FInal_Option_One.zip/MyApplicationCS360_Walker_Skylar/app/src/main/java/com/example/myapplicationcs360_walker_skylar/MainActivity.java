package com.example.myapplicationcs360_walker_skylar;

import android.content.SharedPreferences;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.myapplicationcs360_walker_skylar.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;

import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity {

    SharedPreferences prefs;

    EditText phoneNumber, message;
    Button send;

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        prefs = getSharedPreferences("AppSettings", MODE_PRIVATE);


        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {

            //Gets the current SMS setting
            boolean currentState = prefs.getBoolean("sms_enabled", false);

            //Pop up alert
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("SMS Settings");

            //Shows switch in pop up
            final Switch smsSwitch = new Switch(this);
            smsSwitch.setText("Enable SMS notifications");
            smsSwitch.setChecked(currentState);

            //save button
            builder.setView(smsSwitch);
            builder.setPositiveButton("Save", (dialog, which) -> {
                boolean isEnabled = smsSwitch.isChecked();

                //Gives either message depending on if SMS was disabled or enabled
                Toast.makeText(this, isEnabled ? "SMS Enabled" : "SMS Disabled",
                        Toast.LENGTH_SHORT).show();
            });

            //Cancel button
            builder.setNegativeButton("Cancel", null);
            builder.show();

            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }
}
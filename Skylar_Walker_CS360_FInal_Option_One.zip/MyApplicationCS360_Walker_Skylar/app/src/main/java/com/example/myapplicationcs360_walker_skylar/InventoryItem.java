package com.example.myapplicationcs360_walker_skylar;


//Handles items in the grid
public class InventoryItem {
    public String item;
    public int quantity;

    //basic item constructor
    public InventoryItem(String item, int quantity) {
        this.item = item;
        this.quantity = quantity;
    }
}
